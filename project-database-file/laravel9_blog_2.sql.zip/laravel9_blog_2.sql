-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2022 at 12:22 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel9_blog_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_description`, `category_slug`, `created_at`, `updated_at`) VALUES
(1, 'Animation', NULL, 'animation', '2022-10-17 13:26:03', '2022-10-19 08:28:50'),
(2, 'Video', NULL, 'video', '2022-10-17 13:26:03', '2022-10-19 08:28:40'),
(3, 'Translation', NULL, 'translation', '2022-10-17 13:26:03', '2022-10-19 08:28:29'),
(4, 'Writing', NULL, 'writing', '2022-10-17 13:26:03', '2022-10-19 08:28:18'),
(5, 'Entertainment', NULL, 'entertainment', '2022-10-17 13:26:03', '2022-10-19 08:26:57'),
(6, 'Meat', NULL, 'meat', '2022-10-17 13:26:03', '2022-10-19 08:26:30'),
(7, 'Fish', NULL, 'fish', '2022-10-17 13:26:03', '2022-10-19 08:26:19'),
(8, 'Travelling', NULL, 'travelling', '2022-10-17 13:26:03', '2022-10-19 08:26:06'),
(9, 'Physical exercise', NULL, 'physical-exercise', '2022-10-17 13:26:03', '2022-10-19 08:25:47'),
(10, 'Game', NULL, 'game', '2022-10-17 13:26:03', '2022-10-19 08:25:22'),
(11, 'Android app', NULL, 'android-app', '2022-10-17 13:26:03', '2022-10-19 08:25:13'),
(12, 'web app', NULL, 'web-app', '2022-10-17 13:26:03', '2022-10-19 08:25:00'),
(13, 'Desktop app', NULL, 'desktop-app', '2022-10-17 13:26:03', '2022-10-19 08:24:46'),
(14, 'Programming language', NULL, 'programming-language', '2022-10-17 13:26:03', '2022-10-19 08:24:17'),
(15, 'Flower', NULL, 'flower', '2022-10-17 13:26:03', '2022-10-19 08:23:50'),
(16, 'Fruit', NULL, 'fruit', '2022-10-17 13:26:03', '2022-10-19 08:23:39'),
(17, 'Affiliate marketing', NULL, 'affiliate-marketing', '2022-10-17 13:26:03', '2022-10-19 08:23:18'),
(18, 'Cpa marketing', NULL, 'cpa-marketing', '2022-10-17 13:26:03', '2022-10-19 08:23:04'),
(19, 'Web development', NULL, 'web-development', '2022-10-17 13:26:03', '2022-10-19 08:22:30'),
(20, 'web design', NULL, 'web-design', '2022-10-17 13:26:03', '2022-10-19 08:22:19'),
(21, 'django', 'gdfgdg', 'django', '2022-11-07 03:29:07', '2022-11-07 03:29:07');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `comment_description`, `created_at`, `updated_at`) VALUES
(1, 17, 2, 'This is my first comment in this post. I am very happy to join this blog. This is a very beautiful blog because many people share differt kind of knowledge post.', '2022-10-20 18:00:00', '2022-10-21 00:29:38'),
(3, 17, 1, 'I am rezaul karim. I am the admin of this blog.If you have any problem then contact with us.', '2022-10-20 18:00:00', '2022-10-21 00:00:17'),
(4, 17, 4, 'Sir, i want to learn affiliate marketing.Plz help us.', '2022-10-20 14:41:44', '2022-10-20 14:41:44'),
(5, 20, 4, 'i am a teacher. i am a regular follower of this blog. i am very hapy so that i am a member of this blog. thanks all.', '2022-10-20 14:57:12', '2022-10-20 14:57:12'),
(7, 17, 2, 'dhaka is the capital of bangladesh. we love our country very much.', '2022-10-21 00:33:35', '2022-10-21 00:33:35'),
(9, 17, 2, 'we live in bangladesh. the name offaklfalkjaglkgjlgk', '2022-10-22 06:07:51', '2022-10-22 06:07:51'),
(10, 9, 2, 'A quick brown fox jumps over the lagey dogs. Slow and steady wins the race.', '2022-11-05 18:00:00', '2022-11-06 13:00:25'),
(11, 9, 2, 'Babgladesh is our homeland. We love our country very much.', '2022-11-05 18:00:00', '2022-11-06 13:02:51'),
(12, 9, 3, 'There is no mother who does not love her child. Every mother loves her child.', '2022-11-06 13:05:37', '2022-11-06 13:05:37'),
(13, 17, 3, 'It has been raining for seven days. We can not go school.', '2022-11-06 13:08:40', '2022-11-06 13:08:40'),
(14, 23, 1, 'gadgdhgds dfhdshsfhsf', '2022-11-07 03:56:44', '2022-11-07 03:56:44'),
(15, 23, 2, 'I am going to school. fhsfhfdhfshfsh', '2022-11-06 18:00:00', '2022-11-07 03:58:59');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_10_12_154842_add_role_to_users_table', 1),
(6, '2022_10_13_130443_create_categories_table', 1),
(7, '2022_10_15_062041_create_tags_table', 1),
(8, '2022_10_15_103628_create_posts_table', 1),
(9, '2022_10_20_193400_create_comments_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `post_title`, `post_slug`, `post_description`, `post_image`, `category`, `user_id`, `published_at`, `created_at`, `updated_at`) VALUES
(1, 'Dr. Andre Terry Sr.', 'dr-andre-terry-sr', '<p>Ullam soluta et alias aspernatur voluptas est. Iure nihil blanditiis ea nulla sunt iure. Magni quo autem voluptas nam aut magnam sed aspernatur. Ut explicabo dolorum libero fugit aut dolor. Repudiandae quidem maiores consequuntur illo. Dolorem magni ad mollitia est. Maxime hic error repellat nobis fuga. Autem temporibus aliquid magni ducimus distinctio eveniet. Suscipit consectetur suscipit vero quis porro dolor. Alias ut adipisci consequuntur inventore beatae autem accusantium vel. Aut sint qui assumenda in vel qui qui. Deleniti ut voluptatem sed architecto sunt labore et quo.</p>', 'upload/post_images/223486236blog-thumb-05.jpg', 1, 1, '2022-10-19 12:22:52', '2022-10-17 13:26:03', '2022-10-19 12:22:52'),
(2, 'Mario Runolfsdottir MD', 'mario-runolfsdottir-md', '<p>Ullam ea occaecati explicabo nam molestias asperiores. Nulla quo aut aut ea quas deserunt quia tempore. Quas et labore voluptatem omnis. Et eum omnis libero velit deserunt amet fugit. Occaecati ut sit unde nam. Totam ea beatae laboriosam blanditiis quia aut. Doloribus repudiandae impedit quos vel ut similique dolores. Harum omnis ut repellat rem autem minima. Nostrum nostrum fugit qui dolores odio modi at. Iste et ut placeat aut autem omnis neque. Sit et sunt aut occaecati. Corporis totam odio et dolorum et. Sit ut in ratione quas iste nostrum animi. Dolor dolor omnis id sequi officia. Ut ad sed error illo eos voluptatibus vel ut.</p>', 'upload/post_images/1959641692post1.jpg', 2, 1, '2022-10-19 01:13:26', '2022-10-17 13:26:03', '2022-10-19 01:13:26'),
(3, 'Prof. Maryse Schiller', 'prof-maryse-schiller', '<p>Voluptatem qui architecto esse. Molestiae ullam reiciendis error architecto excepturi occaecati officiis. Reprehenderit consequatur autem provident sit saepe eum suscipit. Recusandae consequatur aliquid dignissimos. Magni minima nulla eligendi rerum laudantium quibusdam. Et quia occaecati alias harum eveniet dolores velit. Molestiae sequi nemo itaque optio sit. Aliquid est tenetur et voluptatem voluptatem eveniet perferendis sunt. Mollitia necessitatibus placeat aspernatur omnis dignissimos. Ut vel omnis non. Eaque totam explicabo et nihil sit et. Pariatur quidem at optio et in. Enim distinctio nam explicabo. Asperiores commodi asperiores enim quasi.</p>', 'upload/post_images/1091980495post-img2.jpg', 3, 1, '2022-10-19 01:13:15', '2022-10-17 13:26:03', '2022-10-19 01:13:15'),
(4, 'Beulah Medhurst', 'beulah-medhurst', '<p>Doloremque deserunt sint consequatur iure saepe. Facilis ut nesciunt iusto qui a doloremque. Beatae in aut unde aut. Et nulla dolorem id officiis nesciunt sit aliquid. Fugit dolore sed laudantium veniam itaque voluptates id et. Delectus quasi ea neque voluptatem. Sit non repellendus accusantium et. Consequatur qui possimus et consequuntur. Tempore error eius ut beatae aspernatur velit. Numquam exercitationem sed culpa modi asperiores. Non autem possimus nemo voluptas. Ex cum fuga soluta corporis vero nostrum necessitatibus. Consequatur aut beatae quis beatae. Nemo qui consequuntur sit officia quis.</p>', 'upload/post_images/1387767428post3.jpg', 4, 1, '2022-10-19 01:13:03', '2022-10-17 13:26:03', '2022-10-19 01:13:03'),
(5, 'Lila Feeney', 'lila-feeney', '<p>Omnis expedita culpa voluptatum iusto occaecati. Est quo accusamus ab explicabo maxime officiis. Cum dolores tenetur consequuntur aperiam id. Et consequatur architecto et corrupti voluptas. Est voluptates reprehenderit unde nihil officiis recusandae dolor. Facilis voluptate inventore sed corrupti. Fugit et quia recusandae voluptatem suscipit eligendi. Ducimus laudantium ut id qui. Ea in laudantium consequatur et. Minus officia odit odio qui quos in ea. Doloremque qui eum ea fugiat minus a. Quia porro vitae voluptatem et expedita ut ducimus. Vero aut quas id facilis vero. At porro velit magnam ratione aut ut.</p>', 'upload/post_images/1693739797latest-post-img2.jpg', 5, 1, '2022-10-19 01:12:46', '2022-10-17 13:26:03', '2022-10-19 01:12:46'),
(6, 'Rosalee Swaniawski PhD', 'rosalee-swaniawski-phd', '<p>Dolores nesciunt nam repudiandae pariatur dolor error. Accusamus ut quis iusto sequi perferendis et. Autem odio officia dicta. Beatae cumque aut ut est reprehenderit velit cum. Odit est id error inventore in officia dolores. Voluptatibus et fugit molestiae temporibus maxime voluptatem repellendus. Est quis qui reiciendis. Facilis dolorem blanditiis voluptatum ipsam minus quia et nihil. Minus minus velit ratione dolore voluptatibus. Molestiae eius soluta et perspiciatis deleniti omnis vel eius. Omnis placeat labore dolor numquam dolorem velit ad. Autem quam similique dicta quisquam laborum. Voluptas voluptatem dignissimos non sunt. Provident vero rerum maxime dolores saepe id.</p>', 'upload/post_images/587468646blog1.png', 6, 1, '2022-10-19 01:12:04', '2022-10-17 13:26:03', '2022-10-19 01:12:04'),
(7, 'Kenny Hudson', 'kenny-hudson', '<p>Enim possimus quasi quos molestiae voluptas a. Quia unde labore similique iure et voluptas temporibus. Quo dolorem quibusdam labore autem aut quia. Numquam veniam atque neque sunt. At id quo cumque cum dolores aut. Praesentium qui deleniti reprehenderit ab officiis est. Hic magni sed dolores cupiditate. Illum ullam sint vitae non eveniet rerum. Aut ut eveniet eius. Repellendus omnis ab ut eligendi cum. Soluta esse ipsam consectetur recusandae qui. Nostrum laborum nihil qui occaecati in enim. Dicta eius quod maxime ad aspernatur quae quos tempore. Dolore a porro vel dolore sit beatae illum. Illum et ullam fuga. Eos dolorum excepturi delectus quas ut autem assumenda.</p>', 'upload/post_images/495411606blog2.png', 7, 1, '2022-10-19 01:11:52', '2022-10-17 13:26:03', '2022-10-19 01:11:52'),
(8, 'Antonio Terry', 'antonio-terry', '<p>Quia maiores quo voluptatem exercitationem non qui. Quis aliquam natus impedit modi et dolor. Libero velit nam voluptas voluptas. Quae necessitatibus rerum omnis est. Sunt nesciunt numquam quod exercitationem atque. Rerum est in minus fugit sunt. Et aperiam quia voluptas dolorem voluptates sequi dolor. Veritatis vel labore sed officiis recusandae iusto ipsa soluta. Quaerat adipisci est ipsum labore. Esse eos voluptates voluptate qui possimus commodi. Vel minus neque quia earum rerum praesentium doloribus. Accusamus sit hic sint cupiditate. Aut explicabo molestiae voluptate corrupti. Sapiente quae sit corporis officia doloribus. Voluptatem est quae qui nostrum est et.</p>', 'upload/post_images/210124355blog3.png', 8, 1, '2022-10-19 01:11:30', '2022-10-17 13:26:03', '2022-10-19 01:11:30'),
(9, 'Do you become a web designer????', 'do-you-become-a-web-designer', '<p>Harum ducimus optio praesentium et laborum nam animi. Est officiis in nam. Vitae architecto rem ipsum. Sed quis et qui recusandae. Ut excepturi delectus dolores ut magnam minus voluptatibus. Tempora debitis quia pariatur quia cupiditate doloremque consequuntur. Harum dolorem blanditiis vero commodi magnam et nihil. Optio doloremque voluptatem blanditiis assumenda beatae. Vel aut nulla natus. Neque cumque ipsa non repellendus dolores voluptas placeat. Et est non est quia provident excepturi ullam numquam. Mollitia delectus nisi quod consequatur ea mollitia aliquid a. Ex quaerat autem vel illum. Autem iure harum asperiores eum perferendis vitae natus et.</p>', 'upload/post_images/144475655latest-post-img1.jpg', 20, 1, '2022-10-19 09:34:01', '2022-10-17 13:26:03', '2022-10-19 09:34:01'),
(10, 'You should learn web design to develop skill', 'you-should-learn-web-design-to-develop-skill', '<p>Quaerat et enim voluptas facilis. Vitae fugit unde molestias voluptatum expedita et nostrum. Qui repudiandae et blanditiis sint in error. Dolorum repellat officiis minus sit error. Ullam sunt et impedit. Non voluptas est sunt fuga ullam. Vel voluptatum ducimus voluptatem non impedit vel maxime ut. Magni autem qui fuga tempore quasi a. Ratione dolores reprehenderit fugiat est corrupti voluptatem. Sed facilis porro fuga vitae voluptates. Amet aliquam ea aperiam. Amet veniam ut amet in. Non quo aut molestiae aperiam labore nobis in. Ullam ea hic et est. Et soluta perferendis eligendi eum. Doloremque sit esse quos facilis consequatur. Vero sed a dolor velit esse magnam aspernatur.</p>', 'upload/post_images/579706310blog-thumb-06.jpg', 20, 1, '2022-10-19 10:29:52', '2022-10-17 13:26:03', '2022-10-19 10:29:52'),
(11, 'Our web design team are very expert', 'our-web-design-team-are-very-expert', '<p>Odio et quidem sequi. Est nihil alias reiciendis eum ut molestias ut. Quia dolor porro incidunt ea blanditiis. Earum enim et omnis est quis magni molestiae facilis. Veritatis aut sint et alias dolores. Autem velit numquam provident quia. Facere maiores numquam eum doloribus beatae eius fugit. Facilis architecto et eum minus. Numquam sed aut aperiam. Quia perferendis porro voluptatem eligendi est rem facilis. Molestiae quia quis sint. Incidunt dicta ut sit. Beatae voluptates eum sed sapiente fuga sed recusandae praesentium. Illo ut nesciunt temporibus ut.</p>', 'upload/post_images/1135394977blog-thumb-05.jpg', 20, 1, '2022-10-19 10:05:34', '2022-10-17 13:26:03', '2022-10-19 10:05:34'),
(12, 'We have exprt web designer', 'we-have-exprt-web-designer', '<p>Et mollitia numquam ea illum ex voluptatibus. Vero blanditiis asperiores sunt sunt. Qui ut voluptate maiores quis omnis et est. Eveniet id sunt porro minima asperiores commodi voluptates. Modi ducimus mollitia est fugit laborum autem non. Non pariatur saepe omnis velit quam sed quod. Deserunt aperiam asperiores qui odit. Harum cum eos voluptatibus impedit omnis velit tempore et. Explicabo omnis ipsa unde praesentium quia eos. Consequatur eaque corporis incidunt. Ut sapiente rem aut incidunt eum vitae. Nulla sunt a qui neque adipisci quia aut. Sunt voluptates aperiam aut dolores est aut odio.</p>', 'upload/post_images/2117006809blog-thumb-04.jpg', 20, 1, '2022-10-19 09:33:00', '2022-10-17 13:26:03', '2022-10-19 09:33:00'),
(13, 'Craig Toy', 'craig-toy', '<p>Fugit ut aut eos dolor. Officia qui non ducimus ipsa qui. Commodi ex quam minus omnis est. Sed iure cumque labore commodi. Natus asperiores asperiores ratione veniam ut. Placeat sint est laudantium. Veniam architecto delectus consequatur. Perspiciatis autem magni temporibus. Delectus nam non dolorem sed repudiandae non cum. Laboriosam nesciunt omnis possimus molestiae minima libero tempora. Omnis at labore quis dolores molestiae molestias iusto. Odit deleniti exercitationem corporis dignissimos. Id suscipit sequi sint omnis dignissimos fugiat. Aut porro est consequatur corporis et repellendus.</p>', 'upload/post_images/866749132blog-post-03.jpg', 13, 1, '2022-10-19 01:08:53', '2022-10-17 13:26:03', '2022-10-19 01:08:53'),
(14, 'Porter Schaefer', 'porter-schaefer', '<p>Harum ipsam dignissimos ut est animi magni quidem qui. Ad consequatur ad aut unde sequi. Dolores ipsam nam voluptas iure. Ut ipsa officia aut qui quidem et. Culpa ut nobis et quam inventore. Impedit sed illo temporibus repellendus totam. Enim laboriosam sed dolorem vero et alias quo. Quaerat minima ipsum sequi excepturi. Esse sint et sed perspiciatis beatae ab dolor. Consequatur reprehenderit quia error qui et. Ducimus ut odio consequuntur dolorem magni est repellendus. At quidem consequatur neque et omnis dolor. Ad dolor quibusdam quae consequatur. Quos nulla voluptas nam adipisci nam aliquam.</p>', 'upload/post_images/340064714blog-post-01.jpg', 14, 1, '2022-10-19 01:08:34', '2022-10-17 13:26:03', '2022-10-19 01:08:34'),
(15, 'Dr. Ernie Wilkinson Sr.', 'dr-ernie-wilkinson-sr', '<p>Quis vel dolor consequatur recusandae. Necessitatibus qui nulla rerum fugiat assumenda earum sunt. Quo placeat nesciunt voluptas cum. Repellat animi ut itaque necessitatibus. Ipsum consequatur quae dolorem non deserunt quo. Optio porro laborum architecto incidunt incidunt blanditiis assumenda. Perspiciatis asperiores illo magni illum. Exercitationem ut aut consequatur repellendus. Nihil voluptas cupiditate incidunt nulla beatae. Libero illum placeat sapiente voluptatibus sit consequuntur. Id facilis amet asperiores libero quasi. Doloremque error neque eveniet nihil. Natus ea ut est amet reiciendis beatae ab ducimus. Doloribus qui at non. Quia voluptas suscipit vel velit.</p>', 'upload/post_images/959885641blog4.png', 15, 1, '2022-10-19 01:08:20', '2022-10-17 13:26:03', '2022-10-19 01:08:20'),
(16, 'Nikolas Gaylord', 'nikolas-gaylord', '<p>Qui aut error quisquam inventore. Libero iure reprehenderit harum eligendi voluptate asperiores. Ut qui id minus. Tenetur et voluptatem eius velit. Corporis iure nam voluptates. Enim aut ut ea est voluptatum quia non velit. Corrupti in quidem adipisci non itaque aliquid. Totam magni placeat quis id. Quod deserunt non aut autem magni iusto praesentium. Consequatur quia dolores modi et. Totam est et inventore. Omnis reiciendis facilis porro sunt laborum non quis qui. Quo quaerat nostrum aliquam exercitationem et aut vel. Odit quia non saepe sapiente ipsum. Repellat perspiciatis omnis dolore. Odio ratione asperiores dolor saepe omnis.</p>', 'upload/post_images/923737591blog-post-02.jpg', 16, 1, '2022-10-19 01:08:01', '2022-10-17 13:26:03', '2022-10-19 01:08:02'),
(17, 'Loyal Turcotte', 'loyal-turcotte', '<p>Dolores ea porro tempore non voluptate earum. Voluptas occaecati unde est sit. Est ut cumque sunt autem. Vero distinctio perferendis commodi reiciendis porro id velit. Quae tempore tempore earum quidem officia ipsum veniam. Laboriosam quis rerum consequatur et. Corrupti fugit explicabo aut eum et laboriosam voluptates. Rerum aut ut vel distinctio. Magnam consequatur omnis doloribus inventore. Itaque quia aut sed dolores. Porro voluptatem qui sed blanditiis debitis nulla dolorem. Pariatur dolorum magni omnis placeat vitae est ut temporibus. Voluptas numquam non ea quia autem vel voluptatem cum.</p>', 'upload/post_images/1059516396blog-thumb-03.jpg', 17, 1, '2022-10-19 01:09:54', '2022-10-17 13:26:04', '2022-10-19 01:09:54'),
(18, 'Do you want to learn website design???', 'do-you-want-to-learn-website-design', '<p>Repellendus optio aliquam et. Ut nihil voluptatem aut eos facilis quasi aut. Aliquid natus magnam alias ullam consequatur accusantium autem. Illum accusamus temporibus dolores pariatur. Laborum facere perspiciatis enim velit. Possimus qui dolores aspernatur quo. Nisi esse nulla odit magnam impedit qui sunt. Placeat et sequi est velit dolorem vel recusandae. Nemo repellendus fuga cum tempora voluptatem quam reprehenderit. Ut at ut reiciendis sed. Aliquam soluta esse iusto laborum sed incidunt dolores. Tempore natus laborum et doloremque tempore minima possimus corporis. Officia laborum aut aliquam. Voluptas dolores assumenda illo eligendi provident.</p>', 'upload/post_images/1759146897blog-post-02.jpg', 20, 1, '2022-10-19 09:32:21', '2022-10-17 13:26:04', '2022-10-19 09:32:21'),
(19, 'Learn website design from ByteCode It center.', 'learn-website-design-from-bytecode-it-center', '<p>Harum magnam sunt esse sequi quaerat. Labore dolorem aspernatur nihil quasi illum maiores error. Saepe commodi voluptatibus esse soluta. Et qui dicta accusamus. Omnis qui nemo qui in totam natus. Neque eum explicabo perspiciatis quas eaque quas repellat. Ab praesentium tempora voluptatem velit exercitationem possimus natus debitis. Animi voluptatibus quis quam sint et. Ad maxime dolorem in eaque. Quod ea pariatur blanditiis repellendus quas voluptas dolor. Placeat assumenda numquam aut quos distinctio ea. Quas soluta aut vel sunt. Unde doloribus facilis incidunt qui quod inventore. Similique eum atque et eum.</p>', 'upload/post_images/1418232133blog-post-01.jpg', 20, 1, '2022-10-19 09:31:35', '2022-10-17 13:26:04', '2022-10-19 09:31:35'),
(20, 'Web desing is a very valuable task', 'web-desing-is-a-very-valuable-task', '<p>Rerum eius architecto libero unde molestiae at impedit. Et eum recusandae id. Omnis sed commodi deleniti eveniet ipsum. Consequuntur provident quod quia similique id. Minus reprehenderit eligendi itaque molestiae porro quaerat. Labore consequatur dolor et ratione in voluptate minima. Vel nam ad incidunt est. Consequuntur et assumenda quam dolores at. Et ducimus temporibus at nemo voluptates qui incidunt. Facilis et et consequuntur nisi error omnis ratione minus. Magnam error dicta libero dolores qui. Velit nam amet ipsum iure ipsum aut eligendi. Velit sed ab itaque alias eligendi. Magni aliquam ab necessitatibus esse eaque. Impedit inventore unde dicta et qui et.</p>', 'upload/post_images/476724832blog4.png', 20, 1, '2022-10-19 09:30:32', '2022-10-17 13:26:04', '2022-10-19 09:30:32'),
(21, 'The quick brown fox jumps over  a lagy dog.', 'the-quick-brown-fox-jumps-over-a-lagy-dog', '<h2 style=\"font-style:italic\"><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</h2>', 'upload/post_images/1015097770blog2.png', 15, 1, '2022-10-22 06:18:59', '2022-10-22 06:17:57', '2022-10-22 06:18:59'),
(22, 'title', 'title', '<h2>fdhfdhfd ncgngfcjj gnfgjgfjgdj jghjgjfjgfjgfjfjg</h2>', 'upload/post_images/238982918download (1).jpg', 15, 1, '2022-11-07 03:52:19', '2022-11-07 03:48:07', '2022-11-07 03:52:19'),
(23, 'sakib', 'sakib', '<p>a<strong>asdasdasda asdasd asdasd asd asdasd ad</strong></p>\r\n\r\n<p><strong><em>asdasd asdasd asdads asdasd da dsad asdd.</em></strong></p>', 'upload/post_images/1833540162download (2).jpg', 21, 1, '2022-11-07 03:55:19', '2022-11-07 03:50:20', '2022-11-07 03:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `post_tag`
--

CREATE TABLE `post_tag` (
  `post_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_tag`
--

INSERT INTO `post_tag` (`post_id`, `tag_id`) VALUES
(20, 1),
(20, 2),
(20, 3),
(19, 1),
(19, 2),
(19, 4),
(19, 9),
(18, 5),
(18, 6),
(18, 7),
(17, 4),
(17, 7),
(17, 9),
(17, 10),
(16, 1),
(16, 2),
(16, 10),
(15, 1),
(15, 2),
(15, 3),
(14, 1),
(14, 2),
(14, 3),
(13, 1),
(13, 2),
(13, 4),
(12, 1),
(12, 2),
(11, 5),
(11, 6),
(11, 10),
(10, 1),
(10, 5),
(10, 10),
(9, 1),
(9, 2),
(1, 7),
(21, 1),
(21, 2),
(21, 3),
(22, 1),
(22, 7),
(23, 1),
(23, 2),
(23, 3),
(23, 4);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tag_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `tag_name`, `tag_description`, `tag_slug`, `created_at`, `updated_at`) VALUES
(1, 'Davion Spinka', NULL, 'shaun-pfeffer', '2022-10-17 13:29:05', '2022-10-17 13:29:05'),
(2, 'Miss Antonia Rogahn', NULL, 'prof-norwood-altenwerth', '2022-10-17 13:29:05', '2022-10-17 13:29:05'),
(3, 'Alvena Stiedemann Jr.', NULL, 'dr-ethelyn-wisozk', '2022-10-17 13:29:05', '2022-10-17 13:29:05'),
(4, 'Erling Lockman', NULL, 'miss-marielle-schmeler-iv', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(5, 'Kaylie Schoen', NULL, 'alexandria-will-phd', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(6, 'Immanuel Littel', NULL, 'prof-demond-leannon-v', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(7, 'Olga Bauch', NULL, 'ashleigh-adams-dvm', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(8, 'Adalberto Schmitt', NULL, 'hildegard-batz', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(9, 'Prof. Davon Boyle', NULL, 'nat-bogisich', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(10, 'Greyson Corwin', NULL, 'mrs-drew-lynch-sr', '2022-10-17 13:29:06', '2022-10-17 13:29:06'),
(11, 'hhh', NULL, 'hhh', '2022-11-07 03:33:08', '2022-11-07 03:33:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role`) VALUES
(1, 'Rezaul Karim', 'admin@gmail.com', NULL, '$2y$10$Q3iUxXni.SyhaatJacQa.OH9illM8WZNBdsu5T0j8EHPZQAiteSwm', NULL, '2022-10-17 13:21:52', '2022-10-17 13:21:52', 1),
(2, 'user', 'user@gmail.com', NULL, '$2y$10$w/EyXDGaZTNTrdN/iE7yTelvCkYMNJrd0gg.B73h3kQ7uEDZZDjz2', NULL, '2022-10-17 13:23:01', '2022-10-17 13:23:01', 0),
(3, 'user2', 'user2@gmail.com', NULL, '$2y$10$Nn6GGkR7Wp/mhmr1kVoPtuPN0B9.PNTqHC9ao9uTNAEztr3Wv3Rdy', NULL, '2022-10-17 13:23:29', '2022-10-17 13:23:29', 0),
(4, 'user3', 'user3@gmail.com', NULL, '$2y$10$ZHYfD258dED1tS9TXEXdo.hs9q4RFgkrrpgP1dZlxXBsHeoBAd3NO', NULL, '2022-10-17 13:24:03', '2022-10-17 13:24:03', 0),
(5, 'Julfikar', 'julfikar@gmail.com', NULL, '$2y$10$vQgdhZAU5e76.VwPqsJ4DO2p7AqEvXRd5ik7XECNoglim/lUwiW.S', NULL, '2022-10-22 06:14:26', '2022-10-22 06:14:26', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `categories_category_name_unique` (`category_name`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_post_title_unique` (`post_title`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tags_tag_name_unique` (`tag_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
